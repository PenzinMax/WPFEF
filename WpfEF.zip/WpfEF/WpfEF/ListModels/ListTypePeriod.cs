﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfEF.Models;

namespace WpfEF.ListModels
{
    public class ListTypePeriod : ObservableCollection<TypePeriod>
    {
        public ListTypePeriod()
        {
            ObservableCollection<TypePeriod> typePeriod =
            new ObservableCollection<TypePeriod>(){
                   new TypePeriod(){Type=1, Name="Работа"},
                   new TypePeriod(){Type=2, Name="Отпуск"},
                   new TypePeriod(){Type=3, Name="Учеба"},
                   new TypePeriod(){Type=4, Name="Больничный"},

            };
            foreach (var type in typePeriod)
            {
                Add(type);
            }
        }
    }
}

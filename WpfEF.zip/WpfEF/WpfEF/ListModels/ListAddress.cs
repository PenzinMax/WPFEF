﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using System.Windows;
using EntityFrameworkCore.Models;
using WpfEF.Units;
using System.Security.Policy;
using WpfEF.Models;
using AuthorizationService.Contexts;

namespace WpfEF.ListModels
{
    public class ListAddress : ObservableCollection<Address>
    {
        public WPFContext db = new WPFContext();
        
        public ListAddress() {


            ObservableCollection<Address> a =
            new ObservableCollection<Address>();

            var b = db.Gars.ToList();
            foreach (var b1 in b)
            {
                a.Add(b1);
            }
            foreach (var x in a)
            {

                Add(x);
            }

        }
    }
}

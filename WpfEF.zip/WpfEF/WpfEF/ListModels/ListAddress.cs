﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using System.Windows;
using EntityFrameworkCore.Models;

namespace WpfEF.ListModels
{
    public class ListAddress : ObservableCollection<Address>
    {
        public ListAddress() { 
            

        }
        
    }
}

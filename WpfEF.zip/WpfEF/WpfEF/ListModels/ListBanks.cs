﻿using AuthorizationService.Contexts;
using EntityFrameworkCore.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfEF.Models;

namespace WpfEF.ListModels
{
    public class ListBanks : ObservableCollection<Bank>
    {
        public WPFContext db = new WPFContext();
        public ListBanks()
        {
            ObservableCollection<Bank> banks =
                new ObservableCollection<Bank>() { };
            var b = db.Banks.ToList();
            foreach (var b1 in b)
            {
                banks.Add(b1);
            }
            foreach (Bank bank in banks)
            {

                Add(bank);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfEF.Models;

namespace WpfApp3
{
    public class Period 
    {
        public DateTime DateStart { get; set; }
        public DateTime DateFinish { get; set; }

        public int Type { get; set; }
        public TypePeriod ?PeriodType { get; set; }
    }
    
}

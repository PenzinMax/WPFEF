﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkCore.Models
{
    public class FileXML
    {
        [Key] public int Id { get; set; }
        public  byte[] File { get; set; }
        public  DateTime CreatedDate { get; set; }
        public DateTime ModDate { get; set; }
        public  int IdBank { get; set; }
        public virtual Bank Banks { get; set; }
    }
}

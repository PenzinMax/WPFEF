﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using System.Collections.ObjectModel;

namespace WpfEF.Units
{

    public class GetAddress //: ObservableCollection<Address>
    {
        public static ObservableCollection<Address> GetList(string url, string addr, string token)
        {
            ObservableCollection<Address> addresses = new ObservableCollection<Address>();
            var jsonString = Task.Run(() => LoadJson(url, addr, token)).Result;

           //ObservableCollection<Address> address = new ObservableCollection<Address>();

            var xml = XDocument.Load(JsonReaderWriterFactory.CreateJsonReader(
            Encoding.UTF8.GetBytes(jsonString), new XmlDictionaryReaderQuotas()));
            Console.WriteLine(xml.Document.ToString());
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml.ToString());
            XmlElement addressElement = doc.DocumentElement;
            XmlNodeList addEl = addressElement.GetElementsByTagName("value");

            Console.WriteLine(addEl.Count.ToString());

            XmlNodeList values = addressElement.SelectNodes("/root/item/value | /root/item/objectGuid");

            Console.WriteLine(values.Count);
            string value = string.Empty;
            string objectGuid = string.Empty;
            int id = 1;

            foreach (XmlNode i in values)
            {
                if (i.Name == "value")
                {
                    value = i.InnerText;
                }

                if (i.Name == "objectGuid")
                {

                    Address a = new Address();
                    a.Id = id++;
                    a.ObjectGuid = i.InnerText;
                    a.Value = value;
                    addresses.Add(a);

                }
            }
            return addresses;
        }
        public static async Task<string> LoadJson(string url, string addr, string token)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Get, $"{url}?addressText={addr}&token={token}");

            var response = await client.SendAsync(request);
            var contentType = response.Content.Headers.ContentType;
            contentType.CharSet = Encoding.UTF8.WebName;
            var content = await response.Content.ReadAsStringAsync();

            string jsonString = content.ToString();

            return jsonString;
        }
    }
}

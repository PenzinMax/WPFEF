﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WpfEF.Migrations
{
    /// <inheritdoc />
    public partial class MigrationByte : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<byte[]>(
                name: "File",
                table: "FileXMLs",
                type: "varbinary(3072)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(700)",
                oldMaxLength: 700);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "File",
                table: "FileXMLs",
                type: "varchar(700)",
                maxLength: 700,
                nullable: false,
                oldClrType: typeof(byte[]),
                oldType: "varbinary(3072)");
        }
    }
}

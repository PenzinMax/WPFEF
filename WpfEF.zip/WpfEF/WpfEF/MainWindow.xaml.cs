﻿using AuthorizationService.Contexts;
using EntityFrameworkCore.Models;
using System.Windows;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using WpfApp3;
using System.Xml;
using WpfEF.Models;

namespace WpfEF
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Period> period = null;
        public WPFContext db = new WPFContext();
        public MainWindow()
        {
            InitializeComponent();
            
            try
            {
                period = new ObservableCollection<Period>();

                FileXML fileXML = db.FileXMLs.FirstOrDefault(f => f.Id == 1);

                //MessageBox.Show(fileXML.File);
               

                if (fileXML != null)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(fileXML.File);
                    XmlElement xmlEl = doc.DocumentElement;

                    foreach (XmlElement p in xmlEl.SelectSingleNode("/person/periods/period"))
                    {
                        
                        var dc = p.SelectSingleNode("//dateStart");
                        var df = p.SelectSingleNode("//dateFinish");
                        var tp = p.SelectSingleNode("//type");
                        Period newPeriod = new Period
                        {
                            DateStart = DateTime.Parse(dc.InnerText),
                            DateFinish = DateTime.Parse(df.InnerText),
                            Type = int.Parse(tp.InnerText)
                        };
                        MessageBox.Show(newPeriod.DateFinish.ToString());

                        period.Add(newPeriod);


                    }

                    
                    XmlElement personElement = (XmlElement)xmlEl.SelectSingleNode("person");
                    if (personElement != null)
                    {
                        var ln = personElement.SelectSingleNode("//lastname");
                        var fn = personElement.SelectSingleNode("//firstname");
                        var mn = personElement.SelectSingleNode("//middlename");

                        PersonInfo pi = new PersonInfo
                        {
                            LastName = ln.InnerText,
                            FirstName = fn.InnerText,
                            MiddleName = mn.InnerText
                        };
                        DataContext = pi;
                    }

                    

                    fileGrid.ItemsSource = period;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SaveXML(object sender, RoutedEventArgs e)
        {
            /*try
            {
                // Получаем объект из базы данных по ID
                FileXML fileXML = db.FileXMLs.FirstOrDefault(f => f.Id == 1);

                if (fileXML != null)
                {
                    // Обновляем поля объекта
                    foreach (Period p in period)
                    {
                        XmlDocument doc = new XmlDocument();
                        XmlElement xmlEl = doc.CreateElement("person");
                        XmlElement dateStartElement = doc.CreateElement("dateStart");
                        dateStartElement.InnerText = p.DateStart.ToString();
                        xmlEl.AppendChild(dateStartElement);

                        XmlElement dateFinishElement = doc.CreateElement("dateFinish");
                        dateFinishElement.InnerText = p.DateFinish.ToString();
                        xmlEl.AppendChild(dateFinishElement);

                        XmlElement typeElement = doc.CreateElement("type");
                        typeElement.InnerText = p.Type.ToString();
                        xmlEl.AppendChild(typeElement);

                        doc.AppendChild(xmlEl);
                    }

                    // Сохраняем изменения в базе данных
                    db.SaveChanges();

                    MessageBox.Show("База данных обновлена");
                }
                else
                {
                    MessageBox.Show("Запись с id 1 не найдена.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("произошла ошибка: " + ex.Message);
            }*/
        }
        private void AddLine() { }
    }
        
}




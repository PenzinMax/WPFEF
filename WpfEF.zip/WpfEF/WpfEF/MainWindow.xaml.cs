﻿using AuthorizationService.Contexts;
using EntityFrameworkCore.Models;
using System.Windows;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using WpfApp3;
using System.Xml;

namespace WpfEF
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Period> period = null;
        public WPFContext db = new WPFContext();
        public MainWindow()
        {
            InitializeComponent();
            
            try
            {
                period = new ObservableCollection<Period>();

                FileXML fileXML = db.FileXMLs.FirstOrDefault(); 
                if (fileXML != null)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(fileXML.File);
                    XmlElement xmlEl = doc.DocumentElement;

                    foreach (XmlElement p in xmlEl.SelectNodes("person"))
                    {
                        var dc = p.SelectSingleNode("dateStart");
                        var df = p.SelectSingleNode("dateFinish");
                        var tp = p.SelectSingleNode("type");
                        Period newPeriod = new Period
                        {
                            DateStart = DateTime.Parse(dc.InnerText),
                            DateFinish = DateTime.Parse(df.InnerText),
                            Type = int.Parse(tp.InnerText)
                        };

                        period.Add(newPeriod);
                    }

                    WPF.ItemsSource = period;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SaveXML(object sender, RoutedEventArgs e)
        {
            XDocument newDoc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XElement("periods",
                    from p in period
                    select new XElement("period",
                        new XElement("dateStart", p.DateStart),
                        new XElement("dateFinish", p.DateFinish),
                        new XElement("type", p.Type)
                    )
                )
            );

            try
            {
                //newDoc.Save(@"C:\Penzin\CSharp\WpfApp3\WpfApp3\bin\Debug\net8.0-windows\NewPeriod.xml");
                MessageBox.Show("XML file saved successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void AddLine() { }
    }
        
}




﻿using AuthorizationService.Contexts;
using EntityFrameworkCore.Models;
using System.Windows;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using WpfApp3;
using System.Xml;
using WpfEF.Models;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;
using System.CodeDom;
using WpfEF.ListModels;
using WpfEF.Units;

namespace WpfEF
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Period> period = null;
        //public ObservableCollection<TypePeriod> typePeriod = null;

        public WPFContext db = new WPFContext();
        public MainWindow()
        {
            InitializeComponent();
            ListAddress addresses = new ListAddress();
           
           //MessageBox.Show(addresses.Count.ToString());
            
            try
            {
                period = new ObservableCollection<Period>();

                FileXML fileXML = db.FileXMLs.FirstOrDefault(f => f.Id == 6);

                if (fileXML != null)
                {
                    byte[] data = fileXML.File;
                    string str = Encoding.UTF8.GetString(data);
                    //MessageBox.Show(str);
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(str);

                    XmlElement xmlEl = doc.DocumentElement;

                    XmlNodeList perEl = xmlEl.GetElementsByTagName("period");

                    for (int i = 1; i < perEl.Count + 1; i++)
                    {
                        var ndf = $"//period[{i}]/dateFinish";
                        var nds = $"//period[{i}]/dateStart";
                        var ntp = $"//period[{i}]/type";
                        var dc = xmlEl.SelectSingleNode(nds);
                        var df = xmlEl.SelectSingleNode(ndf);
                        var tp = xmlEl.SelectSingleNode(ntp);
                        Period newPeriod = new Period
                        {
                            DateStart = DateTime.Parse(dc.InnerText),
                            DateFinish = DateTime.Parse(df.InnerText),
                            Type = int.Parse(tp.InnerText)
                        };

                        period.Add(newPeriod);

                    }

                    XmlElement personElement = doc.DocumentElement;
                    if (personElement != null)
                    {
                        var ln = personElement.SelectSingleNode("//lastname");
                        var fn = personElement.SelectSingleNode("//firstname");
                        var mn = personElement.SelectSingleNode("//middlename");
                        var b = personElement.SelectSingleNode("//bank");
                        var fe = personElement.SelectSingleNode("//addressGuid");
                        PersonInfo pi = new PersonInfo
                        {
                            LastName = ln.InnerText,
                            FirstName = fn.InnerText,
                            MiddleName = mn.InnerText,
                            IdBank = int.Parse(b.InnerText),
                            ObjectGuid = fe.InnerText
                        };
                        DataContext = pi;

                    }
                    

                    fileGrid.ItemsSource = period;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show(period.ToString());
            /*typePeriod = new ObservableCollection<TypePeriod>(){
                   new TypePeriod(){Type=1, Name="Работа"},
                   new TypePeriod(){Type=2, Name="Отпуск"},
                   new TypePeriod(){Type=2, Name="Учеба"},
                   new TypePeriod(){Type=2, Name="Больничный"},

            };
            Period1.ItemsSource = typePeriod;*/
        }


        private void SaveXML(object sender, RoutedEventArgs e)
        {
            XDocument newDoc = new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            new XElement("person",
            new XElement("fullname",
            new XElement("lastname", ((PersonInfo)DataContext).LastName),
            new XElement("firstname", ((PersonInfo)DataContext).FirstName),
            new XElement("middlename", ((PersonInfo)DataContext).MiddleName)
            ),
            new XElement("fileinfo", 
            new XElement("bank",((PersonInfo)DataContext).IdBank),
            new XElement("addressGuid",((PersonInfo)DataContext).ObjectGuid)
            ),
            new XElement("periods",
                                    from p in period
                                    select new XElement("period",
                                    new XElement("dateStart", p.DateStart),
                                    new XElement("dateFinish", p.DateFinish),
                                    new XElement("type", p.Type)
                                    )
                                 )

            )
           
                             );
            
            string xmlString = newDoc.ToString(); // в строку
            
            //MessageBox.Show(xmlString);

            FileXML fileXML = db.FileXMLs.FirstOrDefault(f => f.Id == 6);
            byte[] byteArray = Encoding.UTF8.GetBytes(xmlString);

            if (fileXML != null)
            {
                
                fileXML.File = byteArray; // сохранение строки
            }
            else
            {
                FileXML newFileXML = new FileXML
                {
                    Id = 6,
                    File = byteArray
                };
                db.FileXMLs.Add(newFileXML); // добавление объекта 
            }
           

            try
            {
                db.SaveChanges();// сохранение
                MessageBox.Show("Сохранено");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
            }
        }
        private void OnComboboxTextChanged(object sender, RoutedEventArgs e)
        {
            CB.IsDropDownOpen = true;
            // убрать selection, если dropdown только открылся
            var tb = (TextBox)e.OriginalSource;
            tb.Select(tb.SelectionStart + tb.SelectionLength, 0);
           
            CollectionView cv = (CollectionView)CollectionViewSource.GetDefaultView(CB.ItemsSource);

            cv.Filter = s => ((Bank)s).Name.IndexOf(CB.Text, StringComparison.CurrentCultureIgnoreCase) >= 0;
        }
        private void OnTextBoxChanged(object sender, RoutedEventArgs e)
        {
            SearchItem.IsDropDownOpen = true;
            // убрать selection, если dropdown только открылся
            var tb = (TextBox)e.OriginalSource;
            tb.Select(tb.SelectionStart + tb.SelectionLength, 0);
            SearchItem.ItemsSource = GetAddress.GetList("https://data.pbprog.ru/api/address/full-address/parse", SearchItem.Text, "e41b6504c4fe443fb84f8c9d94003d873455b546");

            CollectionView cv = (CollectionView)CollectionViewSource.GetDefaultView(SearchItem.ItemsSource);

            //cv.Filter = s => ((Address)s).Value.IndexOf(SearchItem.Text, StringComparison.CurrentCultureIgnoreCase) >= 0;
        }
        private void listBank_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }

        private void CB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
        
}



